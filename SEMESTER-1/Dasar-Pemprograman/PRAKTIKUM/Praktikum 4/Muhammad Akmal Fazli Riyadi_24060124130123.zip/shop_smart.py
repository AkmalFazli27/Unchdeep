def diskon (kategori,VIP):
    if kategori == "elektronik":
        if VIP == True:
            return 70 / 100
        return 90 / 100
    elif kategori == "pakaian":
        if VIP == True:
            return 80 / 100
        return 95 / 100
    elif kategori == "makanan":
        if VIP == True:
            return 85 / 100
        return 98 / 100
    elif kategori == "lainnya":
        return 100 / 100
    
def pajak (lokasi):
    if lokasi == "dalam negeri":
        return 110 / 100
    if lokasi == "luar negeri":
        return 120 / 100

def hari_beli (kategori,VIP,hari):
    if (hari == "Jumat" or hari == "Sabtu") and VIP == True:
        return 95 / 100
    if hari == "Minggu":
        return 105 / 100
    if hari == "Rabu" and kategori == "pakaian":
        return 95 / 100
    else:
        return 100 / 100

def hargaAkhir (harga, kategori, VIP, lokasi, hari):
    return (((harga * diskon (kategori,VIP)) * hari_beli (kategori,VIP,hari)) * pajak (lokasi))

print(int(hargaAkhir(100000, "elektronik", True, "dalam negeri", "Senin")))
print(int(hargaAkhir(500000, "pakaian", False, "luar negeri", "Rabu")))