"""
3 ilmuwan memperkirakan pengunjung pada hari D, perkiraan bisa beda, tetapi bisa sama pesis
Hasil perkiraan berdasarkan lamanya jam dari X - Y, lalu dikali dengan range perkiraan 3 ilmuwan.
Hasil tersebut kemudian dibandingkan dengan rata-rata history hari D di pekan-pekan yang lalu.
hasilnya adalah sebuah perbandingan yang dikemas dalam bentuk desimal dengan 5 digit setelah koma. Hasil tersebut bisa saja lebih dari satu, kurang dari satu, atau sama dengan 1.
- pada malam pengunjung menurun dengan hasil hitungannya dikali dengan R%
"""
def pekan_sebelumnya (D):
    if D == "senin":
        return (5000 + 6000 + 4000) / 3
    elif D == "selasa":
        return (7000 + 5000 + 2000) / 3
    elif D == "rabu":
        return (4500 + 3500 + 3000) / 3
    elif D == "kamis":
        return (2900 + 2100 + 2000) / 3
    elif D == "jumat":
        return (3000 + 3000 + 3000) / 3
    elif D == "sabtu":
        return (2000 + 2500 + 2300) / 3
    elif D == "minggu":
        return (1100 + 900 + 1000) / 3

def range (AS, AM, AIP):
    return max(AS, AM, AIP) - min(AS, AM, AIP)

def EstimateGreatLib(D, X, Y, SS, SR, AS, AM, AIP, R):
    # full siang
    if X >= SR and Y <= SS:
        return round(((Y - X) * range (AS, AM, AIP) / pekan_sebelumnya (D)), 5)
    
    # full malam
    if X >= SS and Y >= SS:
        return round(((Y - X) * range (AS, AM, AIP) / pekan_sebelumnya (D)) * R / 100, 5)
    
    # buka sebelum terbit dan tutup setelah terbit, tapi tutup sebelum tenggelam
    if X < SR and Y > SR and Y <= SS:
        # return round(((range (AS, AM, AIP) / pekan_sebelumnya (D)) * (((SR - X) * R/100) + (Y - SR))) / 2, 5)
        return round(((range (AS, AM, AIP) / pekan_sebelumnya (D) * (SR - X) * R/100) + (range (AS, AM, AIP) / pekan_sebelumnya (D) * (Y - SR))) / 2, 5)
    
    # buka sebelum terbenam dan tutup setelah terbenam
    if X >= SR and Y > SS and Y > X and X < SS:
        # return round(((range (AS, AM, AIP) / pekan_sebelumnya (D)) * (((Y - SS) * R/100) + (SS - X))) / 2, 5)
        return round(((range (AS, AM, AIP) / pekan_sebelumnya (D) * (Y - SS) * R/100) + (range (AS, AM, AIP) / pekan_sebelumnya (D) * (SS -X))) / 2, 5)
    
    # buka sebelum terbit dan tutup setelah terbenam
    if X < SR and Y > SS:
        # return round(((range (AS, AM, AIP) / pekan_sebelumnya (D)) * (((SR - X) * R/100) + ((Y - SS) * R/100) + (SS - SR))) / 3, 5)
        round(((range (AS, AM, AIP) / pekan_sebelumnya (D) * (SR - X) * R/100) + (range (AS, AM, AIP) / pekan_sebelumnya (D) * (Y - SS)) + (range (AS, AM, AIP) / pekan_sebelumnya (D) * (SS - SR))) / 3, 5)
    
# (range (AS, AM, AIP) / pekan_sebelumnya (D) * (SR - X) * R/100) + (range (AS, AM, AIP) / pekan_sebelumnya (D) * (Y - SR)






print(EstimateGreatLib("jumat", 7, 8, 17, 6, 4000, 5500, 5000, 3))
print(EstimateGreatLib("senin", 12, 17, 18, 9, 6000, 5000, 4500, 50))
print(EstimateGreatLib("selasa", 8, 16, 20, 12, 7000, 5000, 2000, 75))
print(EstimateGreatLib("selasa", 6, 20, 18, 7, 7000, 5000, 2000, 75))